SELECT * FROM temp_tab;
SELECT "alpha-2" iso_id, name, region
  FROM temp_tab;