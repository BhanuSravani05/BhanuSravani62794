SELECT * from location_62794_tab

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Warsaw', 'jana 25/8');

INSERT INTO  location_62794_tab (country_id, city, address) values ('DE', 'Berlin', 'Liberty 87/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('FR', 'Paris', 'WSB 87/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Wroclav', 'Liberty 87/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'zakopane', 'Liberty 85/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Katowice', 'Liberty 99/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Klimeckiego', 'Liberty 87/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Bonarka', 'Liberty 92/432');
INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Kazimerz', 'Liberty 87/432');

INSERT INTO  location_62794_tab (country_id, city, address) values ('PL', 'Krakowska', 'Liberty 87/432');

SELECT * from job_62794_tab

INSERT INTO  job_62794_tab (department_id, job_name) values (1,'Junior developer');


INSERT INTO job_62794_tab (department_id, job_name) values (2,'Senior developer');
INSERT INTO job_62794_tab (department_id, job_name) values (3,'Project manager');
INSERT INTO job_62794_tab (department_id, job_name) values (4,'Data scientist');
INSERT INTO job_62794_tab (department_id, job_name) values (5,'System analyst');
INSERT INTO job_62794_tab (department_id, job_name) values (6,'Database administrator');
INSERT INTO job_62794_tab (department_id, job_name) values (7,'Network engineer');
INSERT INTO job_62794_tab (department_id, job_name) values (8,'Software tester');
INSERT INTO job_62794_tab (department_id, job_name) values (9,'UX designer');
INSERT INTO job_62794_tab (department_id, job_name) values (10,'Product owner');


SELECT * from emp_62794_tab

INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (3, 1, 'Product owner', 4000)

INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (3, 1, 'bhanu Sravani Gunnada', 4000);

INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (9, 9, 'Analyst', 4287);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (4, 6, 'Coordinator', 7763);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (2, 5, 'Specialist', 4724);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (2, 9, 'Consultant', 5194);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (1, 4, 'Technician', 3073);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (2, 3, 'Supervisor', 3886);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (8, 3, 'Planner', 3031);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (4, 7, 'Strategist', 7972);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (6, 8, 'Advisor', 5792);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (3, 10, 'Facilitator', 6923);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (5, 2, 'Inspector', 3095);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (7, 4, 'Operator', 7074);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (9, 6, 'Controller', 7984);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (1, 8, 'Designer', 3482);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (10, 9, 'Architect', 6723);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (3, 5, 'Engineer', 5342);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (8, 1, 'Scientist', 7991);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (6, 7, 'Researcher', 6894);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (5, 3, 'Instructor', 4721);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (2, 4, 'Trainer', 5577);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (10, 5, 'Mentor', 6379);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (6, 6, 'Coach', 5550);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (7, 5, 'Mediator', 7773);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (8, 7, 'Negotiator', 6352);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (5, 10, 'Liaison', 4046);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (6, 9, 'Representative', 5430);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (9, 2, 'Agent', 6251);
INSERT INTO emp_62794_tab (job_id, Location_id, emp_name, salary) values (4, 1, 'Advocate', 3155);


