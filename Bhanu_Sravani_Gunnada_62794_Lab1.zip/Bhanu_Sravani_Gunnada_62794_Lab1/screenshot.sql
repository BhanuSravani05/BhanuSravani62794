SELECT * FROM temp_tab;
SELECT "alpha-2" iso_id, name, region
  FROM temp_tab;
  
SELECT * FROM region_62794_tab;
SELECT * FROM temp_tab where region = '';




SELECT distinct
            case
              when region = '' then name
              else region 
             end
FROM temp_tab             

INSERT INTO region_62794_tab
SELECT distinct
             case
               when region = '' then name
               else region
             end,
             case
             when region = '' then name
             else region
         end || 'region'
 FROM temp_tab              
 


SELECT * FROM region_62794_tab;

SELECT * FROM country_62794_tab;

INSERT INTO country_12345_tab
SELECT distinct "alpha-2",
    case
        when region = '' then name
        else region
    end,
    name
FROM temp_tab;

SELECT * from department_62794_tab
INSERT into department_62794_tab (department_name) VALUES('HR Department');
INSERT into department_62794_tab (department_name) VALUES('rnd Department');
INSERT into department_62794_tab (department_name) VALUES('HR1 Department');
INSERT into department_62794_tab (department_name) VALUES('HR2 Department');
INSERT into department_62794_tab (department_name) VALUES('HR3 Department');
INSERT into department_62794_tab (department_name) VALUES('HR4 Department');

